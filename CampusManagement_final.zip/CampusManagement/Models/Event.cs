﻿namespace CampusManagement.Models
{
    public class Event
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Date { get; set; } // You can use string for simplicity
        public string Location { get; set; }
        public string EventType { get; set; }
        public string ImageUrl { get; set; }
        public string RegistrationLink { get; set; }
    }
}
