﻿namespace CampusManagement.AppData
{
    public class Students
    {
    }
}
