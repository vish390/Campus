﻿namespace CampusManagement.AppData
{
    public class Teachers
    {
    }
}
