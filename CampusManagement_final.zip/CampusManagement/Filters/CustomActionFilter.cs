﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;
using System.IO;


public class CustomActionFilter : IActionFilter
{
    private readonly string _logFile = "Logs/ActionLogs.txt";

    public void OnActionExecuting(ActionExecutingContext context)
    {
        // Runs before the action
        var actionName = context.ActionDescriptor.DisplayName;
        var time = DateTime.Now;
        File.AppendAllText(_logFile, $"{time} - Executing {actionName}\n");
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        // Runs after the action
        var actionName = context.ActionDescriptor.DisplayName;
        var time = DateTime.Now;
        File.AppendAllText(_logFile, $"{time} - Executed {actionName}\n");
    }
}
