using CampusManagement.Data;
using CampusManagement.Web.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using CampusManagement; // 👈 Match the namespace of DummyEmailSender
using Microsoft.AspNetCore.Identity.UI.Services;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("CampusManagementContextConnection")
    ?? throw new InvalidOperationException("Connection string 'CampusManagementContextConnection' not found.");

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddIdentity<IdentityUser, IdentityRole>()
	.AddEntityFrameworkStores<AppDbContext>()
	.AddDefaultTokenProviders();


builder.Services.Configure<IdentityOptions>(options =>
{
	options.SignIn.RequireConfirmedAccount = false;
});

builder.Services.AddTransient<IEmailSender, DummyEmailSender>();


// Register services
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add<CustomActionFilter>();
});


builder.Services.AddScoped<CustomActionFilter>();

builder.Services.AddMemoryCache();

builder.Services.AddDistributedMemoryCache(); // Required for session storage
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(15); // 👈 Session timeout
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});




// ✅ Fix the login path redirect here
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Identity/Account/Login"; // This matches the default Razor Pages path
    options.AccessDeniedPath = "/Shared/AccessDenied";
});

builder.Services.AddControllersWithViews();
builder.Services.AddControllers();
builder.Services.AddRazorPages();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseMiddleware<RequestLoggingMiddleware>();
app.MapControllers();
app.UseRouting();

app.UseSession(); // ✅ Enables session for the request

app.UseAuthentication();   // ✅ Required before Authorization
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
