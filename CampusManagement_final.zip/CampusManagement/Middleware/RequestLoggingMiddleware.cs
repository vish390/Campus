﻿using Microsoft.AspNetCore.Http;
using System.IO;
using System.Threading.Tasks;

public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string _logFilePath = "Logs/RequestLogs.txt"; // folder for logs

    public RequestLoggingMiddleware(RequestDelegate next)
    {
        _next = next;

        // Ensure the Logs folder exists
        var logDirectory = Path.GetDirectoryName(_logFilePath);
        if (!Directory.Exists(logDirectory))
        {
            Directory.CreateDirectory(logDirectory);
        }
    }

    public async Task InvokeAsync(HttpContext context)
    {

      

        // Log request info
        string logEntry = $"{System.DateTime.Now} | Request: {context.Request.Method} {context.Request.Path}";
        await File.AppendAllTextAsync(_logFilePath, logEntry + "\n");

        // Call the next middleware in the pipeline
        await _next(context);

        // Log response status code
        string responseLog = $"{System.DateTime.Now} | Response: {context.Response.StatusCode} for {context.Request.Path}";
        await File.AppendAllTextAsync(_logFilePath, responseLog + "\n");
    }
}
