﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System.Threading.Tasks;

namespace CampusManagement
{

	public class DummyEmailSender : IEmailSender
	{
		public Task SendEmailAsync(string email, string subject, string htmlMessage)
		{
			// Do nothing (no email will be sent)
			return Task.CompletedTask;
		}
	}


}
