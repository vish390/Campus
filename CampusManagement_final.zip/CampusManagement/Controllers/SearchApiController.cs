﻿using CampusManagement.Web.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class SearchApiController : ControllerBase
    {
        private readonly AppDbContext _context;

        public SearchApiController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("Ping")]
        public IActionResult Ping()
        {
            return Ok("API is alive");
        }
        // GET: api/SearchApi/Students?query=John
        [HttpGet("Students")]
        public IActionResult SearchStudents(string query)
       {
            var students = _context.Students
                .Where(s => s.Name.Contains(query))
                .Select(s => new { s.Id, s.Name, s.Email })
                .ToList();

            return Ok(students);
        }
    }
}
