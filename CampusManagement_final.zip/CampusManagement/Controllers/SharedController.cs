﻿using Microsoft.AspNetCore.Mvc;

namespace CampusManagement.Controllers
{
    public class SharedController : Controller
    {
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View(); // This will use Views/Shared/AccessDenied.cshtml
        }
    }
}
