﻿namespace CampusManagement.Services
{
    public class TeacherFileService
    {
    }
}
