﻿namespace CampusManagement.AppData
{
    public class Courses
    {
    }
}
