﻿using CampusManagement.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CampusManagement.Controllers
{
    public class EventController : Controller
    {
        public IActionResult Index()
        {
            //// Hardcoded list of events
            //var events = new List<Event>
            //{
            //    new Event
            //    {
            //        Title = "Tech Workshop",
            //        Description = "Learn the latest in AI and Machine Learning.",
            //        Date = "25 Aug 2025, 10:00 AM",
            //        Location = "Auditorium",
            //        EventType = "Workshop",
            //        ImageUrl = "/images/techworkshop.jpg",
            //        RegistrationLink = "#"
            //    },
            //    new Event
            //    {
            //        Title = "Cultural Fest",
            //        Description = "Celebrate music, dance, and drama with friends.",
            //        Date = "30 Aug 2025, 5:00 PM",
            //        Location = "Main Hall",
            //        EventType = "Cultural",
            //        ImageUrl = "/images/culturalfest.jpg",
            //        RegistrationLink = "#"
            //    },
            //    new Event
            //    {
            //        Title = "Sports Day",
            //        Description = "Join us for fun games and competitions.",
            //        Date = "05 Sep 2025, 8:00 AM",
            //        Location = "Sports Ground",
            //        EventType = "Sports",
            //        ImageUrl = "/images/sportsday.jpg",
            //        RegistrationLink = "#"
            //    }
            //};

            return View();
        }
    }
}
