﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RoleAuthorizeAttribute : Attribute, IActionFilter
{
    private readonly string[] _roles;

    public RoleAuthorizeAttribute(params string[] roles)
    {
        _roles = roles;
    }

    public void OnActionExecuting(ActionExecutingContext context)
    {
        // Get role from session
        var role = context.HttpContext.Session.GetString("Role");

        // If role not in allowed roles, redirect to AccessDenied page
        if (string.IsNullOrEmpty(role) || !_roles.Contains(role))
        {
            context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
        }
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        // Nothing needed here
    }
}
