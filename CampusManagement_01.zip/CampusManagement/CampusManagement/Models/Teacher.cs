﻿using System.ComponentModel.DataAnnotations;

namespace CampusManagement.Models
{
    public class Teacher
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Required]
        public string Department { get; set; }

        [Display(Name = "Email Address")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Phone Number")]
        public string Phone { get; set; }
    }
}
